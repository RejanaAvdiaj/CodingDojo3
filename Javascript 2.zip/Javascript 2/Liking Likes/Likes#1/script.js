
document.addEventListener("DOMContentLoaded", function() {
    var likeButton = document.querySelector('#button1');
    var likesElement = document.querySelector('#likesCount');
    
    likeButton.addEventListener("click", function() {
    var currentLikes = parseInt(likesElement.innerText); 
        var newLikes = currentLikes + 1;
        likesElement.innerText = newLikes + " like(s)";
    });
});
