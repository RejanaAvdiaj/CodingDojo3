document.addEventListener("DOMContentLoaded", function() {
    function handleLikeButtonClick(likeButtonId, likesCountId) {
        var likeButton = document.querySelector(likeButtonId);
        var likesElement = document.querySelector(likesCountId);

        likeButton.addEventListener("click", function() {
            var currentLikes = parseInt(likesElement.innerText); 
            var newLikes = currentLikes + 1;
            likesElement.innerText = newLikes + " like(s)";
        });
    }

    handleLikeButtonClick('#button1', '#likesCount1');
    handleLikeButtonClick('#button2', '#likesCount2');
    handleLikeButtonClick('#button3', '#likesCount3');
});

