function hide(element) {
    element.remove();
}


document.getElementById('temperature-select').addEventListener('change', function() {
    const selectedUnit = this.value;
    const numbers = document.querySelectorAll('.number, .number1');
    
    numbers.forEach(function(numberElement) {
        let temperature = parseInt(numberElement.textContent);
        if (selectedUnit === 'F') {
            temperature = (temperature * 9/5) + 32;
        } else {
            temperature = (temperature - 32) * 5/9;
        }
        numberElement.textContent = `${temperature.toFixed(0)}°`;
    });
});
