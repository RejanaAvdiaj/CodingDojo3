function hide(element) {
    element.remove();
}

function changeLogin() {
    let loginButton = document.querySelector(".buton2");
    if (loginButton.innerText === "Login") {
        loginButton.innerText = "Logout";
    } else {
        loginButton.innerText = "Login";
    }
}
