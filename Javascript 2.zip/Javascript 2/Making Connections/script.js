
/*Way 1/*
/*function editProfile() {
  var profileName = document.querySelector("#profileName");
  profileName.innerText = "Rejana Avdiaj";
}*/


document.addEventListener("DOMContentLoaded", function() {
  var editProfileLink = document.querySelector("a[href='#'][onclick='editProfile()']");

  editProfileLink.addEventListener("click", function(event) {
    event.preventDefault();
    var newName = prompt("Enter your new name:");
    if (newName !== null && newName.trim() !== "") {
      var profileName = document.querySelector("#profileName");
      profileName.textContent = newName;
    }
  });
});


function removeProfile(profile1) {
  var profile = document.getElementById(profile1);
  if (profile) {
   
    profile.remove();
  }
}

function acceptProfile(profile1) {
  var profile = document.getElementById(profile1);
  if (profile) {
    var connectionsCount = document.querySelector(".new3");
    connectionsCount.textContent = parseInt(connectionsCount.textContent) + 1;
    profile.remove();
  }
}

function rejectProfile(profile1) {
  var profile = document.getElementById(profile1);
  if (profile) {
    var requestsButton = document.getElementById("requestButton");
    requestsButton.textContent = parseInt(requestsButton.textContent) - 1; 
    profile.remove();
  }
}





